/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pilap;

public class main {
    public static void main(String[] args) {
        Pila<String> historialNavegacion = new Pila<>();

        System.out.println("=== 1. VERIFICAR ESTADO INICIAL ===");
        System.out.println("¿La pila está vacía?: " + historialNavegacion.vacia());

        System.out.println("\n=== 2. APILAR ELEMENTOS (PUSH) ===");
        System.out.println("Agregando: google.com");
        historialNavegacion.push("google.com");

        System.out.println("Agregando: github.com");
        historialNavegacion.push("github.com");

        System.out.println("Agregando: stackoverflow.com");
        historialNavegacion.push("stackoverflow.com");

        System.out.println("¿La pila está vacía?: " + historialNavegacion.vacia());
        System.out.println("Cantidad de elementos: " + historialNavegacion.getTamano());

        System.out.println("\n=== 3. CONSULTAR EL TOPE (PEEK) ===");
        System.out.println("Página actual en el tope: " + historialNavegacion.peek());

        System.out.println("\n=== 4. DESAPILAR ELEMENTOS (POP) ===");
        System.out.println("Retrocediendo de página (pop): " + historialNavegacion.pop());
        System.out.println("Nuevo tope tras el pop: " + historialNavegacion.peek());

        System.out.println("Retrocediendo de página (pop): " + historialNavegacion.pop());
        System.out.println("Nuevo tope tras el pop: " + historialNavegacion.peek());

        System.out.println("Retrocediendo de página (pop): " + historialNavegacion.pop());

        System.out.println("\n=== 5. MANEJO DE PILA VACÍA ===");
        System.out.println("¿La pila está vacía?: " + historialNavegacion.vacia());
        System.out.println("Intentando hacer pop en pila vacía:");
        historialNavegacion.pop();
    }
}