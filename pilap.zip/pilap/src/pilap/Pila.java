/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pilap;



public class Pila<T> {
    private Nodo<T> tope;
    private int tamano;

    // Constructor que crea la pila
    public Pila() {
        this.tope = null;
        this.tamano = 0;
    }

    // Push: Agrega un nuevo elemento en el tope
    public void push(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        nuevo.siguiente = tope;
        tope = nuevo;
        tamano++;
    }

    // Pop: Extrae y retorna el elemento del tope
    public T pop() {
        if (vacia()) {
            System.out.println("La pila está vacía. No se puede realizar pop.");
            return null;
        }
        T dato = tope.dato;
        tope = tope.siguiente;
        tamano--;
        return dato;
    }

    // Peek: Consulta el elemento del tope sin extraerlo
    public T peek() {
        if (vacia()) {
            System.out.println("La pila está vacía.");
            return null;
        }
        return tope.dato;
    }

    // Vacía: Verifica si la pila está vacía
    public boolean vacia() {
        return tope == null;
    }

    // Retorna la cantidad de elementos
    public int getTamano() {
        return tamano;
    }
}
