/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package callcenter;

import java.util.Random;

public class Llamada {
    private int id;
    private String cliente;
    private Tipo tipo;
    private double duracion;

    public Llamada(int id, String cliente, Tipo tipo, double duracion) {
        this.id = id;
        this.cliente = cliente;
        this.tipo = tipo;
        this.duracion = duracion;
    }

    public int getId() { return id; }
    public String getCliente() { return cliente; }
    public Tipo getTipo() { return tipo; }
    public double getDuracion() { return duracion; }

    public int obtenerPuntuacion() {
        Random rand = new Random();
        return rand.nextInt(10) + 1;
    }
}