/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package callcenter; // Asegúrate de que coincida con el nombre de tu paquete

import java.util.LinkedList;

public class CallCenter {
    // 1. Atributos de la clase
    private Cola<Llamada> colaLlamadas;
    private double tiempoTotal;
    private LinkedList<Integer> puntuaciones;

    // 2. Constructor
    public CallCenter() {
        this.colaLlamadas = new Cola<>();
        this.tiempoTotal = 0.0;
        this.puntuaciones = new LinkedList<>();
    }

    // 3. Métodos de gestión
    public double getTiempoTotal() {
        return tiempoTotal;
    }

    public void recibirLlamada(Llamada llamada) {
        if (llamada.getTipo() == Tipo.PRIORITARIA) {
            colaLlamadas.enqueuePrioritario(llamada);
        } else {
            colaLlamadas.enqueue(llamada);
        }
    }

    public Llamada atenderLlamada() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas pendientes.");
            return null;
        }

        Llamada llamada = colaLlamadas.dequeue();
        tiempoTotal += llamada.getDuracion();
        int score = llamada.obtenerPuntuacion();
        puntuaciones.add(score);

        System.out.println("Atendiendo a: " + llamada.getCliente() +
                " | Duración: " + llamada.getDuracion() + " min" +
                " | Puntuación obtenida: " + score);
        return llamada;
    }

    public void cancelarLlamada() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas para cancelar.");
            return;
        }
        Llamada cancelada = colaLlamadas.dequeue();
        System.out.println("Llamada cancelada del cliente: " + cancelada.getCliente());
    }

    public void mostrarCola() {
        if (colaLlamadas.empty()) {
            System.out.println("La cola de llamadas está vacía.");
            return;
        }
        System.out.println("--- Llamadas Pendientes ---");
        Nodo<Llamada> actual = colaLlamadas.getInicio();
        while (actual != null) {
            Llamada l = actual.dato;
            System.out.println("ID: " + l.getId() + " | Cliente: " + l.getCliente() +
                    " | Duración: " + l.getDuracion() + " min | Tipo: " + l.getTipo());
            actual = actual.siguiente;
        }
    }

    public double tiempoTotalPendiente() {
        double acumulado = 0;
        Nodo<Llamada> actual = colaLlamadas.getInicio();
        while (actual != null) {
            acumulado += actual.dato.getDuracion();
            actual = actual.siguiente;
        }
        return acumulado;
    }

    public int llamadasPendientes() {
        return colaLlamadas.size();
    }

    public void atenderTodas() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas pendientes para atender.");
            return;
        }
        while (!colaLlamadas.empty()) {
            atenderLlamada();
        }
    }

    public int obtenerpromedio() {
        if (puntuaciones.isEmpty()) {
            return 0;
        }
        int suma = 0;
        for (int score : puntuaciones) {
            suma += score;
        }
        return suma / puntuaciones.size();
    }

    // 4. Método main de prueba
    public static void main(String[] args) {
        CallCenter centro = new CallCenter();

        System.out.println("=== 1. RECIBIENDO LLAMADAS ===");
        centro.recibirLlamada(new Llamada(101, "Juan Pérez", Tipo.NORMAL, 5.0));
        centro.recibirLlamada(new Llamada(102, "Maria López", Tipo.NORMAL, 3.5));
        centro.recibirLlamada(new Llamada(103, "Carlos Gómez (VIP)", Tipo.PRIORITARIA, 8.0));
        centro.recibirLlamada(new Llamada(104, "Ana Martínez", Tipo.NORMAL, 4.0));
        centro.recibirLlamada(new Llamada(105, "Roberto Díaz (Urgente)", Tipo.PRIORITARIA, 2.0));

        System.out.println("\n=== 2. ESTADO INICIAL DE LA COLA ===");
        centro.mostrarCola();
        System.out.println("Total de llamadas pendientes: " + centro.llamadasPendientes());
        System.out.println("Tiempo total pendiente: " + centro.tiempoTotalPendiente() + " min");

        System.out.println("\n=== 3. ATENDIENDO LA PRIMERA LLAMADA ===");
        centro.atenderLlamada();

        System.out.println("\n=== 4. CANCELANDO UNA LLAMADA ===");
        centro.cancelarLlamada();

        System.out.println("\n=== 5. ESTADO DE LA COLA TRAS ATENDER Y CANCELAR ===");
        centro.mostrarCola();
        System.out.println("Tiempo total pendiente actual: " + centro.tiempoTotalPendiente() + " min");

        System.out.println("\n=== 6. ATENDER TODAS LAS LLAMADAS RESTANTES ===");
        centro.atenderTodas();

        System.out.println("\n=== 7. REPORTES FINALES ===");
        System.out.println("Tiempo total atendido: " + centro.getTiempoTotal() + " min");
        System.out.println("Promedio de puntuación recibida: " + centro.obtenerpromedio() + " / 10");
    }
}