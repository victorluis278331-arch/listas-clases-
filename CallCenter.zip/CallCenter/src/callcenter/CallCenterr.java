/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package callcenter;

import java.util.LinkedList;

public class CallCenterr {
    private Cola<Llamada> colaLlamadas;
    private double tiempoTotal;
    private LinkedList<Integer> puntuaciones;

    public CallCenterr() {
        this.colaLlamadas = new Cola<>();
        this.tiempoTotal = 0.0;
        this.puntuaciones = new LinkedList<>();
    }

    public double getTiempoTotal() {
        return tiempoTotal;
    }
public void recibirLlamada(Llamada llamada) {
    if (llamada.getTipo() == Tipo.PRIORITARIA) {
        colaLlamadas.enqueuePrioritario(llamada);
    } else {
        colaLlamadas.enqueue(llamada);
    }
}
    public Llamada atenderLlamada() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas pendientes.");
            return null;
        }

        Llamada llamada = colaLlamadas.dequeue();
        tiempoTotal += llamada.getDuracion();
        int score = llamada.obtenerPuntuacion();
        puntuaciones.add(score);

        System.out.println("Atendiendo a: " + llamada.getCliente() +
                " | Duración: " + llamada.getDuracion() + " min" +
                " | Puntuación obtenida: " + score);
        return llamada;
    }

    public void cancelarLlamada() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas para cancelar.");
            return;
        }
        Llamada cancelada = colaLlamadas.dequeue();
        System.out.println("Llamada cancelada del cliente: " + cancelada.getCliente());
    }

    public void mostrarCola() {
        if (colaLlamadas.empty()) {
            System.out.println("La cola de llamadas está vacía.");
            return;
        }
        System.out.println("--- Llamadas Pendientes ---");
        Nodo<Llamada> actual = colaLlamadas.getInicio();
        while (actual != null) {
            Llamada l = actual.dato;
            System.out.println("ID: " + l.getId() + " | Cliente: " + l.getCliente() +
                    " | Duración: " + l.getDuracion() + " min | Tipo: " + l.getTipo());
            actual = actual.siguiente;
        }
    }

    public double tiempoTotalPendiente() {
        double acumulado = 0;
        Nodo<Llamada> actual = colaLlamadas.getInicio();
        while (actual != null) {
            acumulado += actual.dato.getDuracion();
            actual = actual.siguiente;
        }
        return acumulado;
    }

    public int llamadasPendientes() {
        return colaLlamadas.size();
    }

    public void atenderTodas() {
        if (colaLlamadas.empty()) {
            System.out.println("No hay llamadas pendientes para atender.");
            return;
        }
        while (!colaLlamadas.empty()) {
            atenderLlamada();
        }
    }

    public int obtenerpromedio() {
        if (puntuaciones.isEmpty()) {
            return 0;
        }
        int suma = 0;
        for (int score : puntuaciones) {
            suma += score;
        }
        return suma / puntuaciones.size();
    }
}