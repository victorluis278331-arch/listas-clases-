/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package callcenter;


public class Cola<T> {
    private Nodo<T> inicio;
    private Nodo<T> fin;
    private int tamano;

    public Cola() {
        this.inicio = null;
        this.fin = null;
        this.tamano = 0;
    }

    public void enqueue(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (empty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
        tamano++;
    }

    public void enqueuePrioritario(T dato) {
        Nodo<T> nuevo = new Nodo<>(dato);
        if (empty()) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            nuevo.siguiente = inicio;
            inicio = nuevo;
        }
        tamano++;
    }

    public T dequeue() {
        if (empty()) {
            return null;
        }
        T dato = inicio.dato;
        inicio = inicio.siguiente;
        if (inicio == null) {
            fin = null;
        }
        tamano--;
        return dato;
    }

    public T peek() {
        if (empty()) {
            return null;
        }
        return inicio.dato;
    }

    public boolean empty() {
        return tamano == 0;
    }

    public int size() {
        return tamano;
    }

    public Nodo<T> getInicio() {
        return inicio;
    }
}